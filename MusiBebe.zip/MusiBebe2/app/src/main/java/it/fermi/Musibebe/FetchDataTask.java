package it.fermi.Musibebe;

import android.os.AsyncTask;

public class FetchDataTask extends AsyncTask<Void, Void, String> {

    private MainActivity activity;
    private boolean isItalian;
    private String tipo;

    private String tipoAttivita;
    // Pass the activity to the AsyncTask
    public FetchDataTask(MainActivity activity,boolean isItalian, String tipo,String tipoAttivita) {
        this.isItalian=isItalian;
        this.activity = activity;
        this.tipo=tipo;
        this.tipoAttivita=tipoAttivita;
    }

    @Override
    protected String doInBackground(Void... voids) {
        try {
            return cercaImmagini.output(isItalian,tipo,tipoAttivita);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    protected void onPostExecute(String result) {
        if (result != null) {
            activity.updateUIWithFetchedData(result);
        }
    }
}
