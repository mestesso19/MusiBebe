package it.fermi.Musibebe;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.ListView;
import android.widget.SearchView;
import android.widget.Switch;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private ListView lw;
    private ArrayAdapter<Music> adapt;
    private ArrayList<Music> arrlist;
    private Switch switch1;

    private String json ;
    private ArrayList<String> titoloCanzoni;
    private ArrayList<String> artisti;
    private ArrayList<String> durataCanzoni;
    private ArrayList<String> urlimmagine;
    private boolean previousSwitchState = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        titoloCanzoni = new ArrayList<>();
        artisti = new ArrayList<>();
        durataCanzoni = new ArrayList<>();

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        lw = findViewById(R.id.lista);

        SearchView searchView = findViewById(R.id.search_view);
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                performSearch(query);
                return true;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                performSearch(newText);
                System.out.println(newText);
                return true;
            }
        });

        switch1 = findViewById(R.id.switch1);

        new FetchDataTask(MainActivity.this, previousSwitchState,"TUTTI","$").execute();
        switch1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    switch1.setText("Italia");
                } else {
                    switch1.setText("Mondo");
                }
                // Eseguire l'AsyncTask solo se lo stato dello switch è stato effettivamente modificato
                if (isChecked != previousSwitchState) {

                    previousSwitchState = isChecked;
                    boolean isItalian = isChecked;
                    new FetchDataTask(MainActivity.this, isItalian,"TUTTI","$").execute();
                }
            }
        });

    }
    public void resetState() {
        titoloCanzoni = new ArrayList<>();
        artisti = new ArrayList<>();
        durataCanzoni= new ArrayList<>();
        urlimmagine = new ArrayList<>();

    }

    // Metodo per aggiornare l'interfaccia utente con i dati recuperati
    public void updateUIWithFetchedData(String data) {
        resetState();
        json = data;

        extractTrackInfoFromPlaylist(data);
        if(titoloCanzoni.isEmpty()){
            extractTrackInfoFromQuery(json);
        }
        arrlist = listaMusicDaFile();
        adapt = new MusicAdapter(
                this,
                R.layout.layout_music,
                R.id.titolo,
                arrlist,
                this
        );
        lw.setAdapter(adapt);
    }

    public void pressioneTasto(View v) {
        Button b = (Button) v;
        System.out.println(b.getText().toString());
        new FetchDataTask(MainActivity.this, previousSwitchState,b.getText().toString().toUpperCase(),"$").execute();
        Toast.makeText(getApplicationContext(), b.getText(), Toast.LENGTH_SHORT).show();
    }



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {          // opzione lingua
        int id = item.getItemId();
        if (id == R.id.lingue) {
            Toast.makeText(this, "Lingua cambiata", Toast.LENGTH_SHORT).show();
            if (item.getTitle().equals("Lingua: italiano")) {
                item.setTitle("Lingua: inglese");

            }
            else{
                item.setTitle("Lingua: italiano");

            }
        } else {
            activity_crediti();
        }

        return true;
    }
    public void activity_dettagli() {
        Intent intent = new Intent(this, Dettagli.class);
        startActivity(intent);
    }
    public void activity_crediti() {
        Intent intent = new Intent(this, activity_crediti.class);
        startActivity(intent);
    }
    public void extractTrackInfoFromQuery(String json){
        try {
            // Converti la stringa JSON in un oggetto JSON
            JSONObject jsonObject = new JSONObject(json);

            // Ottieni l'array degli elementi dalla chiave "items"
            JSONArray itemsArray = jsonObject.getJSONObject("tracks").getJSONArray("items");

            // Estrai i dettagli desiderati per ogni elemento nell'array
            for (int i = 0; i < itemsArray.length(); i++) {
                JSONObject item = itemsArray.getJSONObject(i);
                JSONObject album = item.getJSONObject("album");
                JSONArray artists = album.getJSONArray("artists");
                String imageUrl = album.getJSONArray("images").getJSONObject(0).getString("url");


                // Estrai l'artista (considerando solo il primo)
                String artist = artists.getJSONObject(0).getString("name");

                // Estrai il titolo dell'album
                String title = album.getString("name");

                // Estrai la durata (in millisecondi)
                ;
                // Stampa i dettagli estratti
                titoloCanzoni.add(title);
                artisti.add(artist);
                durataCanzoni.add(String.valueOf("0"));
                urlimmagine.add(imageUrl);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }
    public void extractTrackInfoFromPlaylist(String json) {


        try {
            JSONObject playlistJson = new JSONObject(json);
            JSONObject tracksObject = playlistJson.getJSONObject("tracks");
            JSONArray itemsArray = tracksObject.getJSONArray("items");

            for (int i = 0; i < itemsArray.length(); i++) {
                JSONObject item = itemsArray.getJSONObject(i);
                JSONObject trackObject = item.getJSONObject("track");

                String trackTitle = trackObject.getString("name");
                JSONObject albumObject = trackObject.getJSONObject("album");
                JSONArray imagesArray = albumObject.getJSONArray("images");
                JSONArray artistsArray = trackObject.getJSONArray("artists");
                String imageUrl = "";
                if (imagesArray.length() > 0) {
                    JSONObject firstImageObject = imagesArray.getJSONObject(0);
                    imageUrl = firstImageObject.getString("url");

                } else {
                    System.out.println("Nessuna immagine disponibile per questa canzone.");
                }

                String artist = "";
                for (int j = 0; j < artistsArray.length(); j++) {
                    JSONObject artistObject = artistsArray.getJSONObject(j);
                    if (j > 0) {
                        artist += ", ";
                    }
                    artist += artistObject.getString("name");
                }

                long durationMs = trackObject.getLong("duration_ms");
                long durationSec = durationMs / 1000;

                String trackInfo = "Title: " + trackTitle + ", Artist: " + artist + ", Duration: " + durationSec + " seconds";
                titoloCanzoni.add(trackTitle);
                artisti.add(artist);
                durataCanzoni.add(String.valueOf(durationMs));
                urlimmagine.add(imageUrl);

            }
        } catch (JSONException e) {
            e.printStackTrace();
        }


    }

    public ArrayList<Music> listaMusicDaFile() {
        ArrayList<Music> arr = new ArrayList<>();
        try {




            for (int i = 0; i < titoloCanzoni.size(); i++) {


                String titolo = titoloCanzoni.get(i);
                Integer ms= Integer.parseInt(durataCanzoni.get(i))/1000;
                String durata = ms.toString();
                String genere = artisti.get(i);
                Music f = new Music(titolo, Integer.parseInt(durata), genere,urlimmagine.get(i));
                System.out.println(f);
                arr.add(f);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return arr;
    }

    private void performSearch(String query) {
        System.out.println(query);
        new FetchDataTask(MainActivity.this, false,null,query).execute();
    }
}
