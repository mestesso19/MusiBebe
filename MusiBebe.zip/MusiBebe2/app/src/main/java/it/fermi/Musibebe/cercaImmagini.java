package it.fermi.Musibebe;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;




public class cercaImmagini {
    static public final String tokenClient = "c1717a8df47e4dbf91dce7ca9a62c771"; //germiniasi
    static public final String segretTokenClient = "fa857b69de63477293f4f5ab6ad99887"; //germiniasi

    public static String output(boolean isItalian,String tipo,String tipoAttivita) throws Exception {

        String token =   getToken(); //imposta il token da mandare
        String output;
        if(tipoAttivita.equals("$")){
             output = imagineCanzone(token,"a",isItalian,tipo);
        }else{
            output = ricerca(token,tipoAttivita);
        }
        System.out.println(output);


        return output;
    }
    public static String ricerca(String token,String query)throws Exception {
        System.out.println("----------------");
        Map<String,String> map =new HashMap<String,String>();
        String json;
        String request = "https://api.spotify.com/v1/search?q="+query+"&type=track";
        json=cercaCanzone(token,"a",request);
        return json;

    }
    public static String imagineCanzone(String token ,String text,boolean isItalian,String tipo)throws Exception{


        System.out.println("----------------");
        Map<String,String> map =new HashMap<String,String>();
        String json;
        if(tipo.equals("TUTTI")){
            if(isItalian){
                json=cercaCanzoneItalian(token,text);
            }else{
                json=cercaCanzone(token,text);
            }
        }else{
            String reqeust = null;
            switch (tipo){

                case "POP":
                    reqeust = "https://api.spotify.com/v1/playlists/37i9dQZF1EQncLwOalG3K7";
                    break;
                case "RAP":
                    reqeust = "https://api.spotify.com/v1/playlists/37i9dQZF1DWSxF6XNtQ9Rg";
                    break;
                case "REGGAETON":
                    reqeust = "https://api.spotify.com/v1/playlists/37i9dQZF1EQmg9rwHdCwFW";
                    break;
                case "TRAP":
                    reqeust="https://api.spotify.com/v1/playlists/2rZWNJtQiHPQVIaKEPJ23z";
                    break;
                case "INDIE":
                    reqeust="https://api.spotify.com/v1/playlists/37i9dQZF1EQqkOPvHGajmW";
                    break;
                case "ROCK":
                    reqeust="https://api.spotify.com/v1/playlists/37i9dQZF1EQpj7X7UK8OOF";
                    break;
                case "CLASSICA":
                    reqeust="https://api.spotify.com/v1/playlists/37i9dQZF1DWWEJlAGA9gs0";
                    break;
                case "ELETTRONICA":
                    reqeust="https://api.spotify.com/v1/playlists/37i9dQZF1EIeZKM1YFAtwx";
                    break;


            }
            json=cercaCanzone(token,text,reqeust);
        }
        return  json;


    }
    public static String cercaCanzone(String token,String text,String request)throws Exception{
        Scanner scan = new Scanner(System.in);
        String titolo= text;
        if(text.equals("null")){
            System.out.println("\nInserisci il testo da cercare su Spotify:");
            titolo = scan.nextLine();

        }


        titolo = URLEncoder.encode(titolo, "UTF-8");

        URL url = new URL(request);
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setRequestProperty("Authorization", "Bearer " + token );   //  <---  token nell'header "Authorization"
        InputStream in = connection.getInputStream();

        System.out.println("\n\nRisposta: ");
        BufferedReader br = new BufferedReader( new InputStreamReader(in));
        String riga;
        String risposta="";
        while( (riga=br.readLine()) != null ) {
            risposta+=riga;
            System.out.println(riga);
        }
        System.out.println("-----------------------------------------------------------------------------");
        return risposta;
    }
    public static String cercaCanzone(String token,String text)throws Exception{
        Scanner scan = new Scanner(System.in);
        String titolo= text;
        if(text.equals("null")){
            System.out.println("\nInserisci il testo da cercare su Spotify:");
            titolo = scan.nextLine();

        }


        titolo = URLEncoder.encode(titolo, "UTF-8");

        URL url = new URL("https://api.spotify.com/v1/playlists/37i9dQZEVXbMDoHDwVN2tF");
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setRequestProperty("Authorization", "Bearer " + token );   //  <---  token nell'header "Authorization"
        InputStream in = connection.getInputStream();

        System.out.println("\n\nRisposta: ");
        BufferedReader br = new BufferedReader( new InputStreamReader(in));
        String riga;
        String risposta="";
        while( (riga=br.readLine()) != null ) {
            risposta+=riga;
            System.out.println(riga);
        }
        System.out.println("-----------------------------------------------------------------------------");
        return risposta;
    }
    public static String cercaCanzoneItalian(String token,String text)throws Exception{
        Scanner scan = new Scanner(System.in);
        String titolo= text;
        if(text.equals("null")){
            System.out.println("\nInserisci il testo da cercare su Spotify:");
            titolo = scan.nextLine();

        }


        titolo = URLEncoder.encode(titolo, "UTF-8");

        URL url = new URL("https://api.spotify.com/v1/playlists/37i9dQZEVXbIQnj7RRhdSX");
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setRequestProperty("Authorization", "Bearer " + token );   //  <---  token nell'header "Authorization"
        InputStream in = connection.getInputStream();

        System.out.println("\n\nRisposta: ");
        BufferedReader br = new BufferedReader( new InputStreamReader(in));
        String riga;
        String risposta="";
        while( (riga=br.readLine()) != null ) {
            risposta+=riga;
            System.out.println(riga);
        }
        System.out.println("-----------------------------------------------------------------------------");
        return risposta;
    }

    public static String getToken() throws Exception {
        URL url = new URL("https://accounts.spotify.com/api/token");
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setRequestMethod("POST");

        String cliendID = tokenClient; // token germiniasi
        String clientSecret = segretTokenClient; // token segreto germiniasi

        String credenziali = null; //key token da mandare nella richiesta
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            credenziali = Base64.getEncoder().encodeToString( (cliendID+":"+clientSecret).getBytes() );
        }

        connection.addRequestProperty("Authorization","Basic "+credenziali);
        connection.setDoOutput(true);
        OutputStream out = connection.getOutputStream();
        out.write("grant_type=client_credentials".getBytes());


        //System.out.println("\n\nRichiedo un token... ");
        BufferedReader br = new BufferedReader( new InputStreamReader(connection.getInputStream()));


        String riga;
        //System.out.println("\nRisposta ottenuta: ");
        while( (riga=br.readLine()) != null ) {
            System.out.println(riga);
            riga = riga.substring(17,riga.length());
            riga = riga.substring(0,riga.indexOf("\""));
            return riga;
        }

        return null;

    }



}
