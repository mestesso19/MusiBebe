package it.fermi.Musibebe;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;

import java.util.List;

public class MusicAdapter extends ArrayAdapter<Music> {
    private MainActivity temp;
    public MusicAdapter(Context context, int resource, int textViewResourceId, List objects, MainActivity temp) {
        super(context, resource, textViewResourceId, objects);
        this.temp  = temp;
    }

    @Override
    public View getView(int position, View convertView,  ViewGroup parent) {

            View v = super.getView(position, convertView, parent);

            final Music music = getItem(position);

            TextView tw = v.findViewById(R.id.titolo);
            tw.setText(music.getTitolo());

            tw = v.findViewById(R.id.durata);
            if(music.getDurata()!=0){
                tw.setText("" + music.getDurata() + " sec");
            }


            tw = v.findViewById(R.id.genere);
            tw.setText(music.getGenere());
            Button b = v.findViewById(R.id.aba);
            b.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Dettagli.cantante = music.getGenere();
                    Dettagli.titoloCanzone = music.getTitolo();
                    Dettagli.url = music.getUrlImmagine();
                    temp.activity_dettagli();
                }
            });

            return v;
        }

}