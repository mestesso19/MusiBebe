package it.fermi.Musibebe;

import java.util.ArrayList;

public class Music {
    private String titolo;
    private int durata;
    private String genere;
    private String artista;
    private String urlImmagine;

    public Music(String titolo, int durata, String genere,String urlImmagine) {
        this.titolo = titolo;
        this.durata = durata;
        this.genere = genere;
        this.urlImmagine = urlImmagine;
    }

    public String getTitolo() {
        return titolo;
    }

    public String getUrlImmagine() {
        return urlImmagine;
    }

    public void setUrlImmagine(String urlImmagine) {
        this.urlImmagine = urlImmagine;
    }

    public void setTitolo(String titolo) {
        this.titolo = titolo;
    }

    public int getDurata() {
        return durata;
    }

    public void setDurata(int durata) {
        this.durata = durata;
    }

    public String getGenere() {
        return genere;
    }

    public void setGenere(String genere) {
        this.genere = genere;
    }

    public String getArtista() {
        return artista;
    }

    public void setArtista(String trama) {
        this.artista = artista;
    }


    public static ArrayList<Music> listaMusic() {
        ArrayList<Music> lista = new ArrayList<Music>();

        Music f = new Music("Il Padrino", 175, "Drammatico","");
        lista.add( f );

        f = new Music("Le ali della libertà", 142, "Drammatico","");
        lista.add( f );

        f = new Music("Il mago di Oz", 102, "Fantastico","");
        lista.add( f );

        return lista;
    }

    @Override
    public String toString() {
        return titolo + "\n(" + durata + " min )";
    }
}

