package it.fermi.Musibebe;

import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import com.bumptech.glide.Glide;
import org.json.JSONException;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;

public class Dettagli extends AppCompatActivity {
    public static String titoloCanzone = null;
    public static String cantante = null;
    public static String url = null;
    public final String apiUrl = "939317cb0059bfc287b10f65d05576c9";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_dettagli);

        ImageView imageView = findViewById(R.id.immagine);
        String imageUrl = url;
        Glide.with(this)
                .load(imageUrl)
                .into(imageView);

        TextView titolo = findViewById(R.id.textView3);
        titolo.setText(titoloCanzone);

        new FetchLyricsTask().execute();
    }

    private class FetchLyricsTask extends AsyncTask<Void, Void, String> {

        @Override
        protected String doInBackground(Void... voids) {
            String lyrics = null;
            HttpURLConnection connection = null;
            BufferedReader reader = null;
            try {
                String baseUrl = "https://api.musixmatch.com/ws/1.1/matcher.lyrics.get";
                String queryString = String.format("?q_track=%s&q_artist=%s&apikey=%s",
                        URLEncoder.encode(titoloCanzone, "UTF-8"),
                        URLEncoder.encode(cantante, "UTF-8"),
                        apiUrl);
                URL url = new URL(baseUrl + queryString);
                connection = (HttpURLConnection) url.openConnection();
                InputStream in = connection.getInputStream();
                reader = new BufferedReader(new InputStreamReader(in));
                StringBuilder response = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    response.append(line);
                }
                JSONObject jsonResponse = new JSONObject(response.toString());
                JSONObject message = jsonResponse.getJSONObject("message");
                JSONObject body = message.getJSONObject("body");
                JSONObject lyricsObject = body.getJSONObject("lyrics");
                lyrics = lyricsObject.getString("lyrics_body");
            } catch (IOException | JSONException e) {
                e.printStackTrace();
            } finally {
                if (reader != null) {
                    try {
                        reader.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                if (connection != null) {
                    connection.disconnect();
                }
            }
            return lyrics;
        }

        @Override
        protected void onPostExecute(String lyrics) {
            // Display lyrics in your UI
            if (lyrics != null) {
                TextView lyricsTextView = findViewById(R.id.textView4);
                lyricsTextView.setText(lyrics);
            }
        }
    }

}
